
// chart
function showchart1(){
  Highcharts.chart('charts-1', {
      chart: {
          type: 'spline',
          animation: Highcharts.svg, // don't animate in old IE
          duration: 1000,
          marginRight: 10,
          events: {
              load: function () {
                var i=0;
                  // set up the updating of the chart
                  var series = this.series[0];
                  console.log(series);
                  var xarr=[0,1,2,3,4,5,6,7,8,9],
                      yarr1=[2.2,2.7,1.7,2.1,1.4,3.5,4.1,5.5,7.1,6.1],
                      yarr2=[2,3,2,2,1,3,4,5,5,6];//真实值
                  var interval = setInterval(function(){
                  var x = xarr[i], // current time
                      y1=yarr1[i],
                      y2 = yarr2[i];

                  series.addPoint([x,y1], true, false);
                  series.data[i].y=yarr2[i];
                  series.data[i].color= '#FFFF00';
                  console.log(series.data[i]);

                  // series.data[i].visible=false;
                  // series.addPoint([x,y2], true, false);

                  i+=1;
                  if(y2>5)
                    $("#myModal").modal('show');
                  if(i>9){
                    clearInterval(interval);
                  }
                }, 1000);
              }
          }
      },
      title: {
          text: '人口密度曲线'
      },
      xAxis: {
        title: {
            text: '时间/s'
        },
        max:6,
        celling:6,
        floor:0,
        tickAmount: 6,
        allowDecimals: false
      },
      yAxis: {
          title: {
              text: '人口数目/个'
          },
          plotLines: [{
              value: 0,
              width: 1,
              color: '#808080'
          }],
          celling:6,
          floor:0,
          tickAmount: 6,
          allowDecimals: true
      },
      tooltip: {
          formatter: function () {
              return '<b>' + this.series.name + '</b><br/>' +
                  '时间:'+Highcharts.numberFormat(this.x,1) + '<br/>' +
                  '人数:'+Highcharts.numberFormat(this.y, 1);
          }
      },
      legend: {
          enabled: false
      },
      credits: {
          enabled: false
      },
      exporting: {
          enabled: false,
      },
      series: [{
          name: '人口密度',
          color:'#FF9966'
          // data:[6,4,5,6,7,8,9,8,4,6]
          // zones: [{
          //       value: 5,
          //       color: '#7cb5ec',
          //   }, {
          //
          //       color: '#FF9966'
          //   }]
      }]

  });
}


// chart-2
function showchart2(){
    Highcharts.chart('charts-2', {
        chart: {
            type: 'spline',
            animation: Highcharts.svg, // don't animate in old IE
            duration: 1000,
            marginRight: 10,
            events: {
              load: function () {
                var i=0;
                  // set up the updating of the chart
                  var series = this.series[0];
                  console.log(series);
                  var xarr=[1,2,3,4,5,6,7,8,9],
                      yarr=[1,-1,0,-1,2,1,1,0,1];//真实值
                  var interval = setInterval(function(){
                  var x = xarr[i], // current time
                      y= yarr[i];

                  series.addPoint([x,y], true, false);

                  // series.data[i].visible=false;
                  // series.addPoint([x,y2], true, false);

                  i+=1;
                  if(i>9){
                    clearInterval(interval);
                  }
                }, 1000);
              }
            }
        },
        title: {
            text: '人口流速曲线'
        },
        xAxis: {
          title: {
              text: '时间/s'
          },
          max:9,
          celling:9,
          floor:0,
          tickAmount: 9,
          allowDecimals: false
        },
        yAxis: {
            title: {
                text: '人口流速m/s'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }],
            celling:4,
            floor:-1,
            tickAmount: 6,
            allowDecimals: true
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.series.name + '</b><br/>' +
                    '时间:'+Highcharts.numberFormat(this.x,1) + '<br/>' +
                    '流速'+Highcharts.numberFormat(this.y,1);
            }
        },
        legend: {
            enabled: false
        },
        credits: {
            enabled: false
        },
        exporting: {
            enabled: false,
        },
        series: [{
            name: '人口流速',
            color:'#FF9966'
        }]
    });
}

// charts-3,4
window.onload=function(){

  var myvideo1=document.getElementById("my-video1");
  var myvideo2=document.getElementById("my-video2");
  myvideo1.onplay=function(){
    showchart1();
    showchart2();
  };
  myvideo2.onplay=function(){
    showchart1();
    showchart2();
  };




};
